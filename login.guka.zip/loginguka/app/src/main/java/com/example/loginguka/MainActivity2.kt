package com.example.loginguka

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.widget.AppCompatDrawableManager.get
import androidx.appcompat.widget.ResourceManagerInternal.get
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.squareup.picasso.Picasso
import java.lang.reflect.Array.get

class MainActivity2 : AppCompatActivity() {
    private lateinit var name1 : EditText
    private lateinit var url1 : EditText
    private lateinit var savebutton :Button
    private lateinit var imageview :ImageView
    private lateinit var textview: TextView
    private val auth =FirebaseAuth.getInstance()
    private val db = FirebaseDatabase.getInstance().getReference("USER_INFO")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        name1 = findViewById(R.id.name)
        url1 = findViewById(R.id.url)
        imageview = findViewById(R.id.imageView4)
        savebutton = findViewById(R.id.button)
        textview = findViewById(R.id.textView)
        savebutton.setOnClickListener {
            val name = name1.text.toString()
            val url = url1.text.toString()
            val personinfo = PersonInfo(name , url)
            db.child(auth.currentUser?.uid!!).setValue(personinfo)
        }

        db.child(auth.currentUser?.uid!!).addValueEventListener(object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                val userInfo = snapshot.getValue(PersonInfo::class.java) ?: return
                textview.text = userInfo.name
                Picasso.get().load(userInfo.url).into(imageview)
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        })




    }
}