package com.example.loginguka

data class PersonInfo(
    val name: String = "",
    val url : String = ""
)
