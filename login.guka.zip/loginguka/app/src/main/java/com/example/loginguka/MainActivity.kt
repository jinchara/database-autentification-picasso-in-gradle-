package com.example.loginguka

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {

    private lateinit var emaili : EditText
    private lateinit var passwordi : EditText
    private lateinit var buttoni : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        emaili = findViewById(R.id.Email)
        passwordi = findViewById(R.id.Password)
        buttoni = findViewById(R.id.Button)
        buttoni.setOnClickListener {
           val email = emaili.text.toString()
           val password = passwordi.text.toString()
           if (email =="" || password == "" ){
               Toast.makeText(this , "sheiyvanet email/password" , Toast.LENGTH_SHORT).show()
               return@setOnClickListener
           }
           FirebaseAuth.getInstance()
               .signInWithEmailAndPassword(email, password)
               .addOnCompleteListener { task ->
                   if(task.isSuccessful){

                       val intent = Intent(this , MainActivity2 ::class.java)
                       startActivity(intent)
                   }else {
                       Toast.makeText(this , "sheikvanet sworad!" , Toast.LENGTH_SHORT).show()
                   }

               }


        }

    }
}